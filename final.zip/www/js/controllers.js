angular.module('app.controllers', [])
     

     
.controller('homeCtrl', function($scope, $http) {
	
	$http.get("http://ragweb.site88.net/index.php/functions/pub_notices/")
    .then(function (response) {$scope.notices = response.data.records;});

		$scope.doRefresh = function(){
		
	$http.get("http://ragweb.site88.net/index.php/functions/pub_notices/")
    .then(function (response) {$scope.notices = response.data.records;});
	};
	
})
   
.controller('moreInfoCtrl', function($scope) {

})
   

   
 